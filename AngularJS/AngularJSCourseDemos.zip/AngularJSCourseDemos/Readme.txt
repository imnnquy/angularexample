1. Open Chrome browser with non security mode and allow file access

  For example:
  "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"  --disable-web-security -�allow-file-access-from-files 

2. Run html file directly on Chrome browser.